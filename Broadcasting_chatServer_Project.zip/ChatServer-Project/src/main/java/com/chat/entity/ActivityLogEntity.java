package com.chat.entity;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;
import com.chat.enums.ActivityType;

@Getter
@Setter
@Entity
public class ActivityLogEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String userName;
	
	private ActivityType activity;

	public void setUserName(String userName2) {
		// TODO Auto-generated method stub
		
	}

	public void setActivity(ActivityType login) {
		// TODO Auto-generated method stub
		
	}
}
