package com.chat.enums;

public enum ActivityType {

	LOGIN,
	INVALID_LOGIN,
	REGISTER,
	SIGN_OUT,
	INVALID_REGISTER
}
