  
    create table activity_log_entity (
       id bigint not null auto_increment,
        activity integer,
        user_name varchar(255),
        primary key (id)
    ) engine=InnoDB;
    
    create table block_user_entity (
       id bigint not null auto_increment,
        angry_id bigint,
        blocked_id bigint,
        primary key (id)
    ) engine=InnoDB;

    
    create table messages (
       id bigint not null auto_increment,
        from_login varchar(255),
        message varchar(255),
        primary key (id)
    ) engine=InnoDB;

    
    create table messages_records (
       id bigint not null auto_increment,
        message_content varchar(255),
        receiver_name varchar(255),
        sender_name varchar(255),
        primary key (id)
    ) engine=InnoDB;

    
    create table users (
       id bigint not null auto_increment,
        email varchar(50),
        pass_word varchar(64),
        user_name varchar(20),
        primary key (id)
    ) engine=InnoDB;
    
      alter table users 
       add constraint UK_k8d0f2n7n88w1a16yhua64onx unique (user_name);
       
        alter table users 
       add constraint UK_6dotkott2kjsp8vw4d0m25fb7 unique (email);
       
        insert 
    into
        users
        (email, pass_word, user_name) 
    values
        (?, ?, ?);

    insert 
    into
        activity_log_entity
        (activity, user_name) 
    values
        (?, ?);
        
         insert 
    into
        activity_log_entity
        (activity, user_name) 
    values
        (?, ?);
        
         insert 
    into
        users
        (email, pass_word, user_name) 
    values
        (?, ?, ?);
        
  
    insert 
    into
        users
        (email, pass_word, user_name) 
    values
        (?, ?, ?);
 
    insert 
    into
        activity_log_entity
        (activity, user_name) 
    values
        (?, ?);